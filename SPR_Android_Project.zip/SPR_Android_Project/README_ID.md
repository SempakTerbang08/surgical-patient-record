# Surgical Patient Record (SPR) — proyek Android

Ini adalah proyek sumber Android berbasis WebView untuk menjalankan formulir SPR secara lokal di Android. Proyek ini **belum berupa APK terkompilasi**.

## Cara paling realistis dari HP Android saja
1. Unduh dan ekstrak ZIP proyek ini.
2. Unggah seluruh isi folder proyek ke repositori GitHub baru (mis. melalui browser HP).
3. Pastikan folder `.github/workflows/build-apk.yml` ikut terunggah.
4. Buka tab **Actions** di repositori GitHub, pilih **Build SPR APK**, lalu tekan **Run workflow**.
5. Setelah workflow selesai, buka hasil run → bagian **Artifacts** → unduh `SPR-debug-APK`.
6. Ekstrak ZIP artifact dan pasang `app-debug.apk`. Android mungkin meminta izin “Install unknown apps” untuk aplikasi/file manager yang digunakan.

## Catatan penting
- Build debug APK ditujukan untuk uji coba, bukan distribusi produksi.
- Data aplikasi disimpan di localStorage WebView perangkat dan foto bisa memenuhi kapasitas penyimpanan.
- Versi ini belum menerapkan enkripsi database khusus, autentikasi, audit trail, sinkronisasi, atau kepatuhan sertifikasi rekam medis.
- Ekspor DOCX dibuat dari data teks; versi ini belum menyisipkan foto ke dalam DOCX (foto masih tersimpan di data lokal aplikasi).
- Uji dahulu dengan data dummy. Jangan memasukkan data pasien nyata sebelum ditinjau dan disetujui institusi.
